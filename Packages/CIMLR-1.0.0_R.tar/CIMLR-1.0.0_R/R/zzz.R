.onUnload <- function( libpath ) {
    library.dynam.unload("CIMLR", libpath )
}
